<?php

define('APP_NAME','Admin');
define('APP_PATH','./Admin/');
require './ThinkPHP/ThinkPHP.php';