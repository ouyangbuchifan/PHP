<?php
return array(
	//'配置项'=>'配置值'
    'name'=>'Demo1233234',

    'DB_TYPE'=>'mysql',
    'DB_HOST'=>'localhost',
    'DB_NAME'=>'db_study',    // 数据库名
    'DB_USER'=>'root',
    'DB_PWD'=>'123456',
    'DB_PORT'=>3306,
    'DB_CHARSET'=>'utf8',   // 字符集
);