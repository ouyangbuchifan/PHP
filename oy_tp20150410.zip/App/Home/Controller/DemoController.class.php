<?php
namespace Home\Controller;
use Think\Controller;
class DemoController extends Controller {
    public function show(){
        $this->display();
    }
}
?>