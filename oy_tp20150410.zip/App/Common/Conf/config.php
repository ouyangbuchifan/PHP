<?php
return array(
	//'配置项'=>'配置值'

    'URL_HTML_SUFFIX'=>'shtml' //伪静态设置

);